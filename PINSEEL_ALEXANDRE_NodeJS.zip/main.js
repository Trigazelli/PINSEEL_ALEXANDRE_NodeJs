let characters = document.querySelectorAll(".personnage")
let buttons = document.querySelectorAll(".house")
console.log(characters)


// va chercher les données dans l'API
function fetchCharacter(character) {
    return fetch("https://hp-api.lainocs.fr/characters/" + character)

    .then((response) => response.json())
}

// Sert à filtrer les personnages selon leur maison, et en appyant sur l'icône en haut à droite on revient à une version non filtrée
buttons.forEach(function(button) {
    button.addEventListener("click", function() {
        let house = button.getAttribute("id")
        // console.log(house);
        characters.forEach(function(character){
            console.log("dose", character.classList.contains(house), character.id);
            if (house == "") {
                character.style.display = "flex"
            }
            else if (!character.classList.contains(house)) {
                character.style.display = "none"
            }
            else if (character.classList.contains(house)) {
                character.style.display = "flex"
            }
        });
    })
})


//mise en page dynamique pour le nom et les images de fond pour les li
characters.forEach(async function(character) {
    const data = await fetchCharacter(character.getAttribute('id'))
    character.innerHTML =  
    `<div class="name"><h1>${data.name}</h1></div>
    <div class="back"></div>`
    // `<div class="flip-card-inner">
    //     <div class="flip-card-front">
    //     <div class="name"><h1>${data.name}</h1></div>
    //     </div>
    //     <div class="flip-card-back">
    //     <p> Test </p>
    //     </div>
    // </div>`
    // le code ci-dessous choisit le fond de la carte en fonction de la maison inscrite dans l'API
    if (data.house == "") {
        character.style.backgroundImage = `url(${data.image}), url(./images/no_house.jpg)`
    } else {
        character.classList.add(`${data.house}`)
        character.style.backgroundImage = `url(${data.image}), url(./images/${data.house}.jpg)`
    }

    // CI DESSOUS des essais non concluants d'effets pour retourner la carte et afficher les informations, donc désactivés pour l'instant

    // character.addEventListener("click", function() {
    //     character.style.transform = "scaleX(0)"
    //     character.getElementsByClassName("back")[0].classList.toggle("visible")
    //     character.getElementsByClassName("name")[0].classList.toggle("hidden")
    //     if (character.getElementsByClassName("name")[0].classList.contains("hidden")) {
    //         character.style.backgroundImage = `url(./images/card_back.png)`
    //     } else {
    //         character.style.backgroundImage = `url(${data.image}), url(./images/${data.house}.jpg)`
    //     }
    //     character.style.transform = "scaleX(1)"
    //     character.getElementsByClassName("back")[0].innerHTML = `<h1> Nom : ${data.name} </h1>`
    // })


    // Le switch case ci-dessous sert à régler le problème des fautes de frappe
    // switch (data.house[0]) {
    //     case "G":
    //         character.style.backgroundImage = `url(${data.image}), url(./images/Gryffindor.jpg)`
    //         break;

    //     case "S":
    //         character.style.backgroundImage = `url(${data.image}), url(./images/Slytherin.jpg)`
    //         break;
        
    //     case "H":
    //         character.style.backgroundImage = `url(${data.image}), url(./images/Hufflepuff.jpg)`
    //         break;

    //     case "R":
    //         character.style.backgroundImage = `url(${data.image}), url(./images/Ravenclaw.jpg)`
    //         break;

    //     default:
    //         character.style.backgroundImage = `url(${data.image}), url(./images/no_house.jpg)`
    //         break;
    // }



    // Différents console.log() pour gérer les bugs
    // console.log(character.classList)
    // console.log(data);
    // console.log(`url(${data.image}), url(./images/${data.house}.jpg)`);
    // console.log( data.name, data.house[0])
    // console.log(data.house);
    // console.log(`url(./images/${data.house}.jpg)`);
})

// Ci dessous des fonctions de test et de debug avant que le ForEach ne fonctionne, elles sont conservées si besoin

// function fetchCharacter(character) {

//     return fetch("https://hp-api.lainocs.fr/characters/" + character)

//     .then((response) => response.json())

//     .then((data) => {
//         console.log(data)
//     })

// }

// fetchCharacter("harry-potter")

// async function displayCharacter(id) {
//     const data = await fetchCharacter(id)
//     console.log(data[0].name);
//     document.getElementById(id).innerHTML = `
//     <h1>${data[0].name}<h1/>
//     <img src="${data[0].image}" alt="${data[0].name}"/>`
// }
